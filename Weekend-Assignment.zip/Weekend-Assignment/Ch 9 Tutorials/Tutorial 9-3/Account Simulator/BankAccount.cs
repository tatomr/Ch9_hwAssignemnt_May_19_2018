﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Account_Simulator
{
    class BankAccount
    {
        // Field
        private decimal _balance;
        //constructor
        public BankAccount(decimal startingBalance)
        {
            _balance = startingBalance;
        }
        //Balance property (Read-only)
        public decimal Balance
        {
            get { return _balance; }
        }
        //deopsit method
        public void Deposit(decimal amount)
        {
            _balance += amount;
        }
        //withdraw method
        public void Withdraw(decimal amount)
        {
            _balance -= amount;
        }
    }

}
